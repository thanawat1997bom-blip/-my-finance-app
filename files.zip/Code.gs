/**
 * รายรับรายจ่าย — Google Apps Script backend
 *
 * SETUP
 * 1. Open (or create) the Google Sheet you want to use as your database.
 * 2. Extensions > Apps Script. Delete any starter code and paste this file in.
 * 3. Run `setupSheets` once from the Apps Script editor (▶ button) to create
 *    all the tabs and headers automatically. Approve the permissions prompt.
 * 4. Deploy > New deployment > type "Web app".
 *      - Execute as: Me
 *      - Who has access: Anyone
 * 5. Copy the Web App URL it gives you (ends in /exec) and paste it into
 *    the app's ตั้งค่า (Settings) screen.
 *
 * This script intentionally keeps the frontend as the source of truth for
 * balances (computed from opening balances + transactions), and simply logs
 * every transaction/transfer/debt/payment as a row — so the sheet is a
 * readable ledger you can also open and skim by hand.
 */

const SHEET_NAMES = {
  TRANSACTIONS: "Transactions",
  TRANSFERS: "Transfers",
  DEBTS: "Debts",
  DEBT_PAYMENTS: "DebtPayments",
  WALLETS: "Wallets",
  SETTINGS: "Settings",
};

const HEADERS = {
  Transactions: ["ID", "Timestamp", "Date", "Type", "CategoryID", "WalletID", "Amount", "Note", "SlipURL"],
  Transfers: ["ID", "Timestamp", "Date", "FromWalletID", "ToWalletID", "Amount", "Fee", "Note", "SlipURL"],
  Debts: ["ID", "Timestamp", "TypeID", "Name", "InitialAmount", "DueDate", "Status"],
  DebtPayments: ["ID", "Timestamp", "Date", "DebtID", "WalletID", "Amount", "SlipURL"],
  Wallets: ["WalletID", "WalletName", "OpeningBalance"],
  Settings: ["Key", "Value"],
};

/** Run this once manually from the Apps Script editor to bootstrap the sheet. */
function setupSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(HEADERS).forEach((name) => {
    let sheet = ss.getSheetByName(name);
    if (!sheet) sheet = ss.insertSheet(name);
    const headers = HEADERS[name];
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
  });

  // seed default wallets if empty
  const walletSheet = ss.getSheetByName(SHEET_NAMES.WALLETS);
  if (walletSheet.getLastRow() < 2) {
    walletSheet.getRange(2, 1, 4, 3).setValues([
      ["CASH", "เงินสด", 0],
      ["BANK", "ธนาคาร", 0],
      ["DCA", "DCA", 0],
      ["INVEST", "ลงทุน", 0],
    ]);
  }

  // remove the default "Sheet1" if it's still empty and unused
  const def = ss.getSheetByName("Sheet1") || ss.getSheetByName("แผ่นงาน1");
  if (def && def.getLastRow() === 0) ss.deleteSheet(def);

  SpreadsheetApp.getUi().alert("ตั้งค่าโครงสร้างชีทเรียบร้อยแล้ว ✅");
}

function getSheet(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, HEADERS[name].length).setValues([HEADERS[name]]);
  }
  return sheet;
}

function appendRow(sheetName, row) {
  const sheet = getSheet(sheetName);
  sheet.appendRow(row);
}

/** Saves a base64 data URL to Drive (in a "รายรับรายจ่าย - สลิป" folder) and returns its shareable URL. */
function saveSlipIfAny(dataUrl, label) {
  if (!dataUrl || typeof dataUrl !== "string" || dataUrl.indexOf("base64,") === -1) return "";
  try {
    const folderName = "รายรับรายจ่าย - สลิป";
    const folders = DriveApp.getFoldersByName(folderName);
    const folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(folderName);

    const parts = dataUrl.split(",");
    const meta = parts[0]; // e.g. data:image/jpeg;base64
    const mime = meta.substring(meta.indexOf(":") + 1, meta.indexOf(";"));
    const bytes = Utilities.base64Decode(parts[1]);
    const blob = Utilities.newBlob(bytes, mime, `${label}-${Date.now()}.jpg`);
    const file = folder.createFile(blob);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    return file.getUrl();
  } catch (e) {
    return "";
  }
}

function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** Finds the 1-indexed sheet row whose column-A value equals id. Returns -1 if not found. */
function findRowById(sheet, id) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return -1;
  const ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(id)) return i + 2;
  }
  return -1;
}
function updateRowById(sheetName, id, row) {
  const sheet = getSheet(sheetName);
  const r = findRowById(sheet, id);
  if (r === -1) return false;
  sheet.getRange(r, 1, 1, row.length).setValues([row]);
  return true;
}
function deleteRowById(sheetName, id) {
  const sheet = getSheet(sheetName);
  const r = findRowById(sheet, id);
  if (r === -1) return false;
  sheet.deleteRow(r);
  return true;
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const action = body.action;
    const p = body.payload || {};

    switch (action) {
      case "addIncome":
      case "addExpense": {
        const slipUrl = saveSlipIfAny(p.slip, action);
        appendRow(SHEET_NAMES.TRANSACTIONS, [
          p.id, p.ts, p.ts ? p.ts.slice(0, 10) : "", p.type, p.catId, p.walletId, p.amount, p.note || "", slipUrl,
        ]);
        return jsonOut({ ok: true });
      }
      case "addTransfer": {
        const slipUrl = saveSlipIfAny(p.slip, "transfer");
        appendRow(SHEET_NAMES.TRANSFERS, [
          p.id, p.ts, p.ts ? p.ts.slice(0, 10) : "", p.fromId, p.toId, p.amount, p.fee || 0, p.note || "", slipUrl,
        ]);
        return jsonOut({ ok: true });
      }
      case "addDebt": {
        appendRow(SHEET_NAMES.DEBTS, [
          p.id, new Date().toISOString(), p.typeId, p.name, p.initial, p.due || "", p.status || "active",
        ]);
        return jsonOut({ ok: true });
      }
      case "payDebt": {
        const slipUrl = saveSlipIfAny(p.slip, "debtpay");
        appendRow(SHEET_NAMES.DEBT_PAYMENTS, [
          p.id, p.ts, p.ts ? p.ts.slice(0, 10) : "", p.debtId, p.walletId, p.amount, slipUrl,
        ]);
        return jsonOut({ ok: true });
      }
      case "updateTransaction": {
        const slipUrl = saveSlipIfAny(p.slip, "tx-edit");
        const row = [
          p.id, p.ts, p.ts ? p.ts.slice(0, 10) : "", p.type, p.catId, p.walletId, p.amount, p.note || "",
          slipUrl || "", // keep existing slip if no new one was attached during edit
        ];
        // don't blank out an existing slip link when editing without re-attaching one
        const sheet = getSheet(SHEET_NAMES.TRANSACTIONS);
        const r = findRowById(sheet, p.id);
        if (r !== -1 && !slipUrl) row[8] = sheet.getRange(r, 9).getValue();
        updateRowById(SHEET_NAMES.TRANSACTIONS, p.id, row);
        return jsonOut({ ok: true });
      }
      case "deleteTransaction": {
        deleteRowById(SHEET_NAMES.TRANSACTIONS, p.id);
        return jsonOut({ ok: true });
      }
      case "updateTransfer": {
        const slipUrl = saveSlipIfAny(p.slip, "transfer-edit");
        const row = [p.id, p.ts, p.ts ? p.ts.slice(0, 10) : "", p.fromId, p.toId, p.amount, p.fee || 0, p.note || "", slipUrl || ""];
        const sheet = getSheet(SHEET_NAMES.TRANSFERS);
        const r = findRowById(sheet, p.id);
        if (r !== -1 && !slipUrl) row[8] = sheet.getRange(r, 9).getValue();
        updateRowById(SHEET_NAMES.TRANSFERS, p.id, row);
        return jsonOut({ ok: true });
      }
      case "deleteTransfer": {
        deleteRowById(SHEET_NAMES.TRANSFERS, p.id);
        return jsonOut({ ok: true });
      }
      case "updateDebtPayment": {
        const slipUrl = saveSlipIfAny(p.slip, "debtpay-edit");
        const row = [p.id, p.ts, p.ts ? p.ts.slice(0, 10) : "", p.debtId, p.walletId, p.amount, slipUrl || ""];
        const sheet = getSheet(SHEET_NAMES.DEBT_PAYMENTS);
        const r = findRowById(sheet, p.id);
        if (r !== -1 && !slipUrl) row[6] = sheet.getRange(r, 7).getValue();
        updateRowById(SHEET_NAMES.DEBT_PAYMENTS, p.id, row);
        return jsonOut({ ok: true });
      }
      case "deleteDebtPayment": {
        deleteRowById(SHEET_NAMES.DEBT_PAYMENTS, p.id);
        return jsonOut({ ok: true });
      }
      case "setOpeningBalances": {
        // payload is { CASH: 0, BANK: 0, DCA: 0, INVEST: 0 }
        const sheet = getSheet(SHEET_NAMES.WALLETS);
        const lastRow = sheet.getLastRow();
        if (lastRow >= 2) {
          const ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
          ids.forEach((row, i) => {
            const wid = row[0];
            if (Object.prototype.hasOwnProperty.call(p, wid)) {
              sheet.getRange(i + 2, 3).setValue(p[wid]);
            }
          });
        }
        return jsonOut({ ok: true });
      }
      case "ping": {
        return jsonOut({ ok: true, message: "pong" });
      }
      default:
        return jsonOut({ ok: false, error: "unknown action: " + action });
    }
  } catch (err) {
    return jsonOut({ ok: false, error: String(err) });
  }
}

/** Optional: lets you sanity-check the deployment by visiting the /exec URL directly in a browser. */
function doGet(e) {
  return jsonOut({ ok: true, message: "รายรับรายจ่าย API is running. POST requests only for writes." });
}
